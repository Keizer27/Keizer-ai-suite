"use client";

import { useState, useRef } from "react";
import Image from "next/image";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { realisticImageEditor } from "@/ai/flows/realistic-image-editor";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { LoadingSpinner } from "@/components/loading-spinner";
import { Upload, Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  photo: z.any().refine((files) => files?.length > 0, "Image is required."),
  editDescription: z.string().min(10, { message: "Description must be at least 10 characters." }),
});

export default function ImageEditorPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [originalImage, setOriginalImage] = useState<string | null>(null);
  const [editedImage, setEditedImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      editDescription: "",
    },
  });

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      form.setValue("photo", event.target.files);
      const reader = new FileReader();
      reader.onloadend = () => {
        setOriginalImage(reader.result as string);
        setEditedImage(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const toBase64 = (file: File): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);
    });

  const handleDownload = () => {
    if (editedImage) {
      const link = document.createElement("a");
      link.href = editedImage;
      link.download = "edited-image.png";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true);
    setEditedImage(null);
    try {
      const photoDataUri = await toBase64(values.photo[0]);
      const result = await realisticImageEditor({
        photoDataUri,
        editDescription: values.editDescription,
      });
      setEditedImage(result.editedPhotoDataUri);
    } catch (error) {
      console.error("Error editing image:", error);
      toast({
        title: "Error Editing Image",
        description: "There was an issue editing your image. Please check your file, description, and API key, then try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Realistic Image Editor</CardTitle>
          <CardDescription>Upload an image and describe the edits you want to see.</CardDescription>
        </CardHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="photo"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Image</FormLabel>
                    <FormControl>
                      <div 
                        className="relative flex h-64 w-full cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed border-border bg-card hover:bg-muted"
                        onClick={() => fileInputRef.current?.click()}
                      >
                        <Input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          ref={fileInputRef}
                          onChange={handleFileChange}
                        />
                        {originalImage ? (
                           <Image src={originalImage} alt="Original" layout="fill" objectFit="contain" className="rounded-lg" />
                        ) : (
                          <div className="text-center text-muted-foreground">
                            <Upload className="mx-auto h-12 w-12" />
                            <p className="mt-2">Click or drag file to this area to upload</p>
                            <p className="text-xs">PNG, JPG, GIF up to 10MB</p>
                          </div>
                        )}
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="editDescription"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Edit Description</FormLabel>
                    <FormControl>
                      <Textarea placeholder="e.g., Change the background to a sunny beach. Make the sky more blue." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
            <CardFooter>
              <Button type="submit" disabled={isLoading || !originalImage}>
                {isLoading && <LoadingSpinner className="mr-2" />}
                Edit Image
              </Button>
            </CardFooter>
          </form>
        </Form>
      </Card>
      
      {(isLoading || editedImage) && (
        <Card>
          <CardHeader>
             <div className="flex justify-between items-center">
              <CardTitle>Edited Image</CardTitle>
              {editedImage && (
                <Button variant="ghost" size="icon" onClick={handleDownload}>
                  <Download className="h-4 w-4" />
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent className="flex h-full min-h-[400px] items-center justify-center">
            {isLoading ? (
              <div className="text-center">
                <LoadingSpinner className="mx-auto h-12 w-12" />
                <p className="mt-4 text-muted-foreground">Editing your image...</p>
              </div>
            ) : (
              editedImage && <Image src={editedImage} alt="Edited" width={500} height={500} className="rounded-lg object-contain" />
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
