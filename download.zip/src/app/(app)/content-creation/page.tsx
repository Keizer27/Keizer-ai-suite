"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { generateContent } from "@/ai/flows/content-creation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { LoadingSpinner } from "@/components/loading-spinner";
import { useToast } from "@/hooks/use-toast";
import { ClipboardCopy } from "lucide-react";

const formSchema = z.object({
  businessDescription: z.string().min(10, { message: "Description must be at least 10 characters." }),
});

// Define ContentOutput type locally as it cannot be exported from a 'use server' file.
type ContentOutput = {
  copy: string;
};

export default function ContentCreationPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [content, setContent] = useState<ContentOutput | null>(null);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      businessDescription: "",
    },
  });

  const handleCopy = () => {
    if (content) {
      navigator.clipboard.writeText(content.copy).then(() => {
        toast({ title: "Copied to clipboard!" });
      });
    }
  };

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true);
    setContent(null);
    try {
      const result = await generateContent(values);
      setContent(result);
    } catch (error) {
      console.error("Error generating content:", error);
      toast({
        title: "Error Generating Content",
        description: "There was an issue creating your content. Please check your details and API key, then try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Content Creation</CardTitle>
          <CardDescription>Generate marketing copy for your business.</CardDescription>
        </CardHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="businessDescription"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Business/Product Description</FormLabel>
                    <FormControl>
                      <Textarea rows={6} placeholder="e.g., A mobile app that helps users find the best local coffee shops." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
            <CardFooter>
              <Button type="submit" disabled={isLoading}>
                {isLoading && <LoadingSpinner className="mr-2" />}
                Generate Content
              </Button>
            </CardFooter>
          </form>
        </Form>
      </Card>
      
      {(isLoading || content) && (
        <Card className="flex flex-col">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Generated Content</CardTitle>
              {content && (
                <Button variant="ghost" size="icon" onClick={handleCopy}>
                  <ClipboardCopy className="h-4 w-4" />
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent className="flex-grow">
            {isLoading ? (
              <div className="flex h-full items-center justify-center">
                <div className="text-center">
                  <LoadingSpinner className="mx-auto h-12 w-12" />
                  <p className="mt-4 text-muted-foreground">Generating content...</p>
                </div>
              </div>
            ) : content && (
               <Textarea
                  readOnly
                  value={content.copy}
                  className="mt-1 h-full min-h-[300px] w-full resize-none whitespace-pre-wrap"
                />
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
