"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { solveMathProblem } from "@/ai/flows/math-solver";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { LoadingSpinner } from "@/components/loading-spinner";
import { useToast } from "@/hooks/use-toast";
import { ClipboardCopy } from "lucide-react";

const formSchema = z.object({
  problem: z.string().min(3, { message: "Problem must be at least 3 characters." }),
});

export default function MathSolverPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [solution, setSolution] = useState("");
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      problem: "",
    },
  });

  const handleCopy = () => {
    navigator.clipboard.writeText(solution).then(() => {
      toast({ title: "Copied to clipboard!" });
    });
  };

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true);
    setSolution("");
    try {
      const result = await solveMathProblem(values);
      setSolution(result.solution);
    } catch (error) {
      console.error("Error solving problem:", error);
      toast({
        title: "Error Solving Problem",
        description: "There was an issue solving the problem. Please check your input and API key, then try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Math Solver</CardTitle>
          <CardDescription>Solve complex mathematical problems and equations.</CardDescription>
        </CardHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="problem"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Problem / Equation</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., solve 2x + 5 = 15 for x" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
            <CardFooter>
              <Button type="submit" disabled={isLoading}>
                {isLoading && <LoadingSpinner className="mr-2" />}
                Solve Problem
              </Button>
            </CardFooter>
          </form>
        </Form>
      </Card>
      
      {(isLoading || solution) && (
        <Card className="flex flex-col">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Solution</CardTitle>
              {solution && (
                <Button variant="ghost" size="icon" onClick={handleCopy}>
                  <ClipboardCopy className="h-4 w-4" />
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent className="flex-grow">
            {isLoading ? (
              <div className="flex h-full items-center justify-center">
                <div className="text-center">
                  <LoadingSpinner className="mx-auto h-12 w-12" />
                  <p className="mt-4 text-muted-foreground">Solving your problem...</p>
                </div>
              </div>
            ) : (
              <Textarea
                readOnly
                value={solution}
                className="h-full min-h-[400px] w-full resize-none whitespace-pre-wrap"
              />
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
