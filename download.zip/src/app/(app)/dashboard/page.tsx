"use client";

import { useState, useRef, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { chat } from "@/ai/flows/chat-flow";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { LoadingSpinner } from "@/components/loading-spinner";
import { SendHorizonal } from "lucide-react";
import { KeizerLogo } from "@/components/keizer-logo";
import { Form, FormField, FormItem, FormControl } from "@/components/ui/form";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  message: z.string().min(1, "Message cannot be empty."),
});

// Define ChatMessage type locally as it cannot be exported from a 'use server' file.
export type ChatMessage = {
  role: "user" | "model";
  content: string;
};

export default function DashboardPage() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      message: "",
    },
  });
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  async function onSubmit(values: z.infer<typeof formSchema>) {
    const userMessage: ChatMessage = { role: "user", content: values.message };
    setMessages((prev) => [...prev, userMessage]);
    setIsLoading(true);
    form.reset();

    try {
      const history = [...messages, userMessage];
      const result = await chat({ history });
      const aiMessage: ChatMessage = { role: "model", content: result.reply || "" };
      setMessages((prev) => [...prev, aiMessage]);
    } catch (error) {
      console.error("Error with chat:", error);
      const errorMessage: ChatMessage = {
        role: "model",
        content: "I seem to be having some trouble right now. Please try again in a moment. If the problem continues, please ensure your API key is configured correctly.",
      };
      setMessages((prev) => [...prev, errorMessage]);
      toast({
        title: "Chat Error",
        description: "Failed to get a response from the AI. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="flex h-[calc(100vh-5rem)] flex-col">
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        <div className="flex items-start gap-4">
            <Avatar className="h-8 w-8 border-2 border-primary/50">
                <KeizerLogo />
            </Avatar>
            <div className="max-w-[75%] rounded-lg p-3 text-sm whitespace-pre-wrap shadow-md bg-muted rounded-bl-none">
                <p>Hello! I'm Keizer, your AI assistant. How can I help you today?</p>
            </div>
        </div>
        
        {messages.map((message, index) => (
          <div key={index} className={cn("flex items-start gap-4", message.role === "user" ? "justify-end" : "")}>
            {message.role === "model" && (
              <Avatar className="h-8 w-8 border-2 border-primary/50">
                <KeizerLogo />
              </Avatar>
            )}
            <div
              className={cn("max-w-[75%] rounded-lg p-3 text-sm whitespace-pre-wrap shadow-md",
                message.role === "user"
                  ? "bg-primary text-primary-foreground rounded-br-none"
                  : "bg-muted rounded-bl-none"
              )}
            >
              <p>{message.content}</p>
            </div>
            {message.role === "user" && (
              <Avatar className="h-8 w-8">
                <AvatarFallback>U</AvatarFallback>
              </Avatar>
            )}
          </div>
        ))}
        {isLoading && (
          <div className="flex items-start gap-4">
            <Avatar className="h-8 w-8 border">
               <KeizerLogo />
            </Avatar>
            <div className="max-w-[75%] rounded-lg bg-muted p-3">
              <LoadingSpinner />
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>
      <div className="border-t p-4 bg-background">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="flex items-center gap-2">
            <FormField
              control={form.control}
              name="message"
              render={({ field }) => (
                <FormItem className="flex-1">
                  <FormControl>
                    <Input
                      placeholder="Ask me anything..."
                      autoComplete="off"
                      disabled={isLoading}
                      {...field}
                    />

                  </FormControl>
                </FormItem>
              )}
            />
            <Button type="submit" size="icon" disabled={isLoading}>
              <SendHorizonal className="h-4 w-4" />
              <span className="sr-only">Send</span>
            </Button>
          </form>
        </Form>
      </div>
    </div>
  );
}
