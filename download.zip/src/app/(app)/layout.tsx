"use client";

import * as React from "react";
import {
  Sidebar,
  SidebarProvider,
  SidebarTrigger,
  SidebarInset,
  SidebarHeader,
  SidebarContent,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
} from "@/components/ui/sidebar";
import { KeizerLogo } from "@/components/keizer-logo";
import {
  MessageCircle,
  FileText,
  PenSquare,
  Image,
  FileVideo,
  Blocks,
  Sigma,
  CodeXml,
  Mail,
  Megaphone,
  Clipboard,
} from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion } from "framer-motion";

const toolLinks = [
  {
    name: "AI Chat",
    href: "/dashboard",
    icon: MessageCircle,
  },
  {
    name: "Report Generator",
    href: "/report-generator",
    icon: FileText,
  },
  {
    name: "Article Writer",
    href: "/article-writer",
    icon: PenSquare,
  },
  {
    name: "Image Editor",
    href: "/image-editor",
    icon: Image,
  },
  {
    name: "Script Writer",
    href: "/script-writer",
    icon: FileVideo,
  },
    {
    name: "Resume Writer",
    href: "/resume-writer",
    icon: Clipboard,
  },
  {
    name: "Content Creation",
    href: "/content-creation",
    icon: Blocks,
  },
  {
    name: "Math Solver",
    href: "/math-solver",
    icon: Sigma,
  },
  {
    name: "Code Generator",
    href: "/code-generator",
    icon: CodeXml,
  },
  {
    name: "Email Responder",
    href: "/email-responder",
    icon: Mail,
  },
  {
    name: "Social Media Post",
    href: "/social-media-post-generator",
    icon: Megaphone,
  },
];

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  return (
    <SidebarProvider>
      <div className="flex min-h-screen">
        <Sidebar>
          <SidebarHeader>
            <div className="flex items-center gap-3">
              <KeizerLogo />
              <h1 className="font-headline text-lg font-semibold text-primary">Keizer</h1>
            </div>
          </SidebarHeader>
          <SidebarContent>
            <SidebarMenu>
              {toolLinks.map((link) => (
                <SidebarMenuItem key={link.href}>
                  <Link href={link.href} className="w-full">
                    <SidebarMenuButton
                      isActive={pathname === link.href}
                      tooltip={link.name}
                    >
                      <link.icon />
                      <span>{link.name}</span>
                    </SidebarMenuButton>
                  </Link>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarContent>
        </Sidebar>
        <SidebarInset>
          <header className="sticky top-0 z-10 flex h-14 items-center gap-4 border-b bg-background px-4 sm:static sm:h-auto sm:border-0 sm:bg-transparent sm:px-6 md:hidden">
            <SidebarTrigger />
             <div className="flex items-center gap-2">
              <KeizerLogo className="h-6 w-6"/>
              <h1 className="font-headline text-lg font-semibold text-primary">Keizer</h1>
            </div>
          </header>
          <main className="flex-1 p-4 sm:p-6">
             <motion.div
              key={pathname}
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.2, ease: "easeOut" }}
            >
              {children}
            </motion.div>
          </main>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
}
