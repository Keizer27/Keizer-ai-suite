"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { writeArticle } from "@/ai/flows/article-writer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { LoadingSpinner } from "@/components/loading-spinner";
import { useToast } from "@/hooks/use-toast";
import { ClipboardCopy } from "lucide-react";

const formSchema = z.object({
  topic: z.string().min(10, { message: "Topic must be at least 10 characters." }),
  context: z.string().optional(),
  style: z.string().min(10, { message: "Style requirements must be at least 10 characters." }),
});

export default function ArticleWriterPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [article, setArticle] = useState("");
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      topic: "",
      context: "",
      style: "Formal tone, include citations where appropriate.",
    },
  });

  const handleCopy = () => {
    navigator.clipboard.writeText(article).then(() => {
      toast({ title: "Copied to clipboard!" });
    });
  };

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true);
    setArticle("");
    try {
      const result = await writeArticle(values);
      setArticle(result.article);
    } catch (error) {
      console.error("Error writing article:", error);
      toast({
        title: "Error Generating Article",
        description: "There was an issue creating your article. Please check your details and API key, then try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Article & Journal Writer</CardTitle>
          <CardDescription>Generate well-structured articles and journal entries on any topic.</CardDescription>
        </CardHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="topic"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Topic</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., The future of renewable energy" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="context"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Context (Optional)</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Provide any additional context or key points to include." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="style"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Style Requirements</FormLabel>
                    <FormControl>
                      <Textarea placeholder="e.g., Casual tone, for a blog post, no citations needed." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
            <CardFooter>
              <Button type="submit" disabled={isLoading}>
                {isLoading && <LoadingSpinner className="mr-2" />}
                Write Article
              </Button>
            </CardFooter>
          </form>
        </Form>
      </Card>
      
      {(isLoading || article) && (
        <Card className="flex flex-col">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Generated Article</CardTitle>
              {article && (
                <Button variant="ghost" size="icon" onClick={handleCopy}>
                  <ClipboardCopy className="h-4 w-4" />
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent className="flex-grow">
            {isLoading ? (
              <div className="flex h-full items-center justify-center">
                <div className="text-center">
                  <LoadingSpinner className="mx-auto h-12 w-12" />
                  <p className="mt-4 text-muted-foreground">Writing your article...</p>
                </div>
              </div>
            ) : (
              <Textarea
                readOnly
                value={article}
                className="h-full min-h-[400px] w-full resize-none whitespace-pre-wrap"
              />
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
