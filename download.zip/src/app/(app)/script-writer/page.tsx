"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { scriptWriter } from "@/ai/flows/script-writer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { LoadingSpinner } from "@/components/loading-spinner";
import { useToast } from "@/hooks/use-toast";
import { ClipboardCopy } from "lucide-react";

const formSchema = z.object({
  context: z.string().min(10, { message: "Context must be at least 10 characters." }),
  details: z.string().min(10, { message: "Details must be at least 10 characters." }),
});

export default function ScriptWriterPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [script, setScript] = useState("");
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      context: "",
      details: "A 5-minute YouTube video script. Target audience is young adults.",
    },
  });

  const handleCopy = () => {
    navigator.clipboard.writeText(script).then(() => {
      toast({ title: "Copied to clipboard!" });
    });
  };

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true);
    setScript("");
    try {
      const result = await scriptWriter(values);
      setScript(result.script);
    } catch (error) {
      console.error("Error writing script:", error);
      toast({
        title: "Error Generating Script",
        description: "There was an issue creating your script. Please check your details and API key, then try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Script Writer</CardTitle>
          <CardDescription>Generate scripts for videos, podcasts, and more.</CardDescription>
        </CardHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="context"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Context</FormLabel>
                    <FormControl>
                      <Textarea rows={5} placeholder="e.g., A video about the history of the internet, focusing on the ARPANET." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="details"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Details</FormLabel>
                    <FormControl>
                      <Textarea rows={5} placeholder="e.g., Length, style, target audience, key talking points." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
            <CardFooter>
              <Button type="submit" disabled={isLoading}>
                {isLoading && <LoadingSpinner className="mr-2" />}
                Write Script
              </Button>
            </CardFooter>
          </form>
        </Form>
      </Card>
      
      {(isLoading || script) && (
        <Card className="flex flex-col">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Generated Script</CardTitle>
              {script && (
                <Button variant="ghost" size="icon" onClick={handleCopy}>
                  <ClipboardCopy className="h-4 w-4" />
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent className="flex-grow">
            {isLoading ? (
              <div className="flex h-full items-center justify-center">
                <div className="text-center">
                  <LoadingSpinner className="mx-auto h-12 w-12" />
                  <p className="mt-4 text-muted-foreground">Writing your script...</p>
                </div>
              </div>
            ) : (
              <Textarea
                readOnly
                value={script}
                className="h-full min-h-[400px] w-full resize-none whitespace-pre-wrap"
              />
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
