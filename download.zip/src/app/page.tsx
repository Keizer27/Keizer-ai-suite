import {
  MessageCircle,
  FileText,
  PenSquare,
  Image,
  FileVideo,
  Blocks,
  Sigma,
  CodeXml,
  Mail,
  Megaphone,
  Clipboard,
} from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { KeizerLogo } from "@/components/keizer-logo";

const tools = [
  {
    name: "AI Chat",
    href: "/dashboard",
    icon: MessageCircle,
    description: "Engage in natural conversations with an intelligent AI assistant.",
  },
  {
    name: "Report Generator",
    href: "/report-generator",
    icon: FileText,
    description: "Generate comprehensive and well-structured reports on any topic.",
  },
  {
    name: "Article Writer",
    href: "/article-writer",
    icon: PenSquare,
    description: "Create high-quality articles and journal entries effortlessly.",
  },
  {
    name: "Image Editor",
    href: "/image-editor",
    icon: Image,
    description: "Describe your desired edits and let AI transform your images.",
  },
  {
    name: "Script Writer",
    href: "/script-writer",
    icon: FileVideo,
    description: "Generate scripts for videos, podcasts, and other creative projects.",
  },
  {
    name: "Resume Writer",
    href: "/resume-writer",
    icon: Clipboard,
    description: "Build a professional resume or CV with AI-powered assistance.",
  },
  {
    name: "Content Creation",
    href: "/content-creation",
    icon: Blocks,
    description: "Generate compelling marketing copy and slogans for your brand.",
  },
  {
    name: "Math Solver",
    href: "/math-solver",
    icon: Sigma,
    description: "Solve complex mathematical problems and equations with ease.",
  },
  {
    name: "Code Generator",
    href: "/code-generator",
    icon: CodeXml,
    description: "Create code snippets in various languages from natural language.",
  },
  {
    name: "Email Responder",
    href: "/email-responder",
    icon: Mail,
    description: "Draft professional and effective email replies in seconds.",
  },
  {
    name: "Social Media Post",
    href: "/social-media-post-generator",
    icon: Megaphone,
    description: "Create engaging social media posts tailored for any platform.",
  },
];

export default function LandingPage() {
  return (
    <div className="flex min-h-screen w-full flex-col bg-background">
      <header className="sticky top-0 z-50 flex items-center justify-between p-4 bg-background/80 backdrop-blur-sm border-b border-border">
        <div className="flex items-center gap-2">
          <KeizerLogo />
          <span className="font-headline text-xl text-primary">Keizer</span>
        </div>
        <nav className="flex items-center gap-4">
          <Link href="/login">
             <Button variant="ghost">Login</Button>
          </Link>
          <Link href="/signup">
             <Button>Sign Up</Button>
          </Link>
        </nav>
      </header>

      <main className="flex-1">
        <section className="container mx-auto flex flex-col items-center justify-center space-y-6 py-24 text-center">
          <h1 className="font-headline text-6xl md:text-8xl text-primary animate-fade-in-down">
            Your Ultimate AI Assistant
          </h1>
          <p className="mt-4 max-w-2xl mx-auto text-lg text-muted-foreground animate-fade-in-up">
            Meet Keizer – a powerful suite of AI tools designed to enhance your
            productivity, creativity, and problem-solving capabilities. Choose
            any tool below to get started.
          </p>
          <Link href="/dashboard">
            <Button size="lg" className="mt-6">Get Started for Free</Button>
          </Link>
        </section>

        <section className="container mx-auto pb-24">
           <div className="mt-12 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {tools.map((tool, i) => (
              <Link href={tool.href} key={tool.name}>
                <Card 
                  className="h-full flex flex-col justify-between cursor-pointer group"
                  style={{ animationDelay: `${i * 100}ms` }}
                >
                    <CardHeader>
                      <div className="flex items-center gap-4">
                        <tool.icon className="h-8 w-8 text-primary transition-transform duration-300 group-hover:scale-125" />
                        <CardTitle className="font-headline text-2xl">{tool.name}</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <CardDescription>{tool.description}</CardDescription>
                    </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </section>
      </main>
       
       <footer className="border-t">
        <div className="container flex flex-col items-center justify-center gap-4 py-10 md:h-24 md:flex-row md:py-0">
          <p className="text-center text-sm leading-loose text-muted-foreground">
            © {new Date().getFullYear()} Keizer AI. All Rights Reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
