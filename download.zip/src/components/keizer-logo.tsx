import * as React from 'react';

export const KeizerLogo = (props: React.SVGProps<SVGSVGElement>) => (
  <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <g clipPath="url(#clip0_104_2)">
      <path d="M6 4H10L17 12.016L22 4H26L18.5 16L26 28H22L17 19.984L10.016 28H6L13.5 16L6 4Z" fill="url(#paint0_linear_104_2)"/>
    </g>
    <defs>
      <linearGradient id="paint0_linear_104_2" x1="6" y1="4" x2="26" y2="28" gradientUnits="userSpaceOnUse">
        <stop stopColor="#7f3f98"/>
        <stop offset="1" stopColor="#52dc54"/>
      </linearGradient>
      <clipPath id="clip0_104_2">
        <rect width="32" height="32" rx="8" fill="white"/>
      </clipPath>
    </defs>
  </svg>
);
