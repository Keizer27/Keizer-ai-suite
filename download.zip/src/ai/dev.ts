import { config } from 'dotenv';
config();

import '@/ai/flows/article-writer.ts';
import '@/ai/flows/ai-report-generator.ts';
import '@/ai/flows/script-writer.ts';
import '@/ai/flows/realistic-image-editor.ts';
import '@/ai/flows/content-creation.ts';
import '@/ai/flows/math-solver.ts';
import '@/ai/flows/chat-flow.ts';
import '@/ai/flows/code-generator.ts';
import '@/ai/flows/email-responder.ts';
import '@/ai/flows/social-media-post-generator.ts';
import '@/ai/flows/resume-writer.ts';
