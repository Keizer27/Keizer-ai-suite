'use server';
/**
 * @fileOverview A conversational AI flow for the chat interface.
 *
 * - chat - A function that takes chat history and returns a response.
 * - ChatInput - The input type for the chat function.
 * - ChatOutput - The return type for the chat function.
 * - ChatMessage - A single message object in the chat history.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const ChatMessageSchema = z.object({
  role: z.enum(['user', 'model']),
  content: z.string(),
});
export type ChatMessage = z.infer<typeof ChatMessageSchema>;

const ChatInputSchema = z.object({
  history: z.array(ChatMessageSchema),
});
export type ChatInput = z.infer<typeof ChatInputSchema>;

const ChatOutputSchema = z.object({
  reply: z.string().describe("The AI's response to the user."),
});
export type ChatOutput = z.infer<typeof ChatOutputSchema>;

export async function chat({ history }: ChatInput): Promise<ChatOutput> {
  // Validate that history is a non-empty array before proceeding.
  if (!Array.isArray(history) || history.length === 0) {
    const errorMsg = 'Chat history is invalid or empty.';
    console.error(errorMsg, history);
    return { reply: `An internal error occurred: ${errorMsg}` };
  }

  // The last message in the history is the user's current prompt.
  const lastMessage = history[history.length - 1];

  // The rest of the array is the conversational history.
  const conversationHistory = history.slice(0, -1);
  
  // The model requires a user message to start the conversation.
  // We ensure the last message is from the user.
  if (lastMessage.role !== 'user') {
    const errorMsg = 'The final message in the history must be from the user.';
    console.error(errorMsg, history);
    return { reply: `An internal error occurred: ${errorMsg}` };
  }

  try {
    // Generate a response using the provided history and the user's prompt.
    const response = await ai.generate({
      system: `You are Keizer, a friendly, witty, and highly intelligent AI assistant. Your goal is to be as helpful as possible while maintaining an engaging and slightly playful personality.`,
      // The history needs to be mapped to the specific format the AI model expects.
      history: conversationHistory.map((msg) => ({
        role: msg.role,
        content: [{ text: msg.content }],
      })),
      // The content of the last message is the actual prompt for the AI.
      prompt: lastMessage.content,
    });

    // Ensure a string is always returned to prevent client-side errors.
    return {
      reply: response.text ?? 'I seem to be at a loss for words. Please try again.',
    };
  } catch (error)
  {
    console.error('Error during AI generation in chat flow:', error);
    // Provide a user-friendly error message on failure.
    return { reply: 'Sorry, I encountered an error generating a response. The AI model may be temporarily unavailable.' };
  }
}
