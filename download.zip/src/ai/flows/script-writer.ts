'use server';

/**
 * @fileOverview Script writing AI agent.
 *
 * - scriptWriter - A function that handles the script writing process.
 * - ScriptWriterInput - The input type for the scriptWriter function.
 * - ScriptWriterOutput - The return type for the scriptWriter function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ScriptWriterInputSchema = z.object({
  context: z.string().describe('The context or background information for the script.'),
  details: z.string().describe('Specific details or requirements for the script, such as length, style, and target audience.'),
});
type ScriptWriterInput = z.infer<typeof ScriptWriterInputSchema>;

const ScriptWriterOutputSchema = z.object({
  script: z.string().describe('The generated script.'),
});
type ScriptWriterOutput = z.infer<typeof ScriptWriterOutputSchema>;

export async function scriptWriter(input: ScriptWriterInput): Promise<ScriptWriterOutput> {
  return scriptWriterFlow(input);
}

const prompt = ai.definePrompt({
  name: 'scriptWriterPrompt',
  input: {schema: ScriptWriterInputSchema},
  output: {schema: ScriptWriterOutputSchema},
  prompt: `You are an AI script writing assistant. Use the following context and details to create a script.

Context: {{{context}}}
Details: {{{details}}}

Script:`,
});

const scriptWriterFlow = ai.defineFlow(
  {
    name: 'scriptWriterFlow',
    inputSchema: ScriptWriterInputSchema,
    outputSchema: ScriptWriterOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
