'use server';
/**
 * @fileOverview An AI agent for generating email replies.
 *
 * - generateEmailReply - A function that generates an email reply.
 * - GenerateEmailReplyInput - The input type for the generateEmailReply function.
 * - GenerateEmailReplyOutput - The return type for the generateEmailReply function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const GenerateEmailReplyInputSchema = z.object({
  emailContent: z.string().describe('The content of the original email.'),
  tone: z.string().describe('The desired tone for the reply (e.g., professional, casual).'),
});
type GenerateEmailReplyInput = z.infer<typeof GenerateEmailReplyInputSchema>;

const GenerateEmailReplyOutputSchema = z.object({
  reply: z.string().describe('The generated email reply.'),
});
type GenerateEmailReplyOutput = z.infer<typeof GenerateEmailReplyOutputSchema>;

export async function generateEmailReply(input: GenerateEmailReplyInput): Promise<GenerateEmailReplyOutput> {
  return generateEmailReplyFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateEmailReplyPrompt',
  input: { schema: GenerateEmailReplyInputSchema },
  output: { schema: GenerateEmailReplyOutputSchema },
  prompt: `You are a helpful assistant that writes email replies.
Based on the original email content and desired tone, write a suitable reply.

Original Email:
{{{emailContent}}}

Desired Tone: {{{tone}}}
`,
});

const generateEmailReplyFlow = ai.defineFlow(
  {
    name: 'generateEmailReplyFlow',
    inputSchema: GenerateEmailReplyInputSchema,
    outputSchema: GenerateEmailReplyOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);
    return output!;
  }
);
