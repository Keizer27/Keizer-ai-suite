'use server';

/**
 * @fileOverview Article and journal writer AI agent.
 *
 * - writeArticle - A function that handles the article writing process.
 * - WriteArticleInput - The input type for the writeArticle function.
 * - WriteArticleOutput - The return type for the writeArticle function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const WriteArticleInputSchema = z.object({
  topic: z.string().describe('The topic of the article or journal.'),
  context: z.string().describe('Additional context or information to guide the writing.'),
  style: z.string().describe('Requirements for the article style, such as tone and citations.'),
});
type WriteArticleInput = z.infer<typeof WriteArticleInputSchema>;

const WriteArticleOutputSchema = z.object({
  article: z.string().describe('The generated article or journal content.'),
});
type WriteArticleOutput = z.infer<typeof WriteArticleOutputSchema>;

export async function writeArticle(input: WriteArticleInput): Promise<WriteArticleOutput> {
  return writeArticleFlow(input);
}

const prompt = ai.definePrompt({
  name: 'writeArticlePrompt',
  input: {schema: WriteArticleInputSchema},
  output: {schema: WriteArticleOutputSchema},
  prompt: `You are an AI assistant specialized in writing articles and journals.

You will use the provided topic, context, and style requirements to generate the content.

Topic: {{{topic}}}
Context: {{{context}}}
Style Requirements: {{{style}}}

Write the article or journal based on the above information.`,
});

const writeArticleFlow = ai.defineFlow(
  {
    name: 'writeArticleFlow',
    inputSchema: WriteArticleInputSchema,
    outputSchema: WriteArticleOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
