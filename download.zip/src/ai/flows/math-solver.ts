'use server';

/**
 * @fileOverview Math problem solver AI agent.
 *
 * - solveMathProblem - A function that handles solving mathematical problems.
 * - MathSolverInput - The input type for the solveMathProblem function.
 * - MathSolverOutput - The return type for the solveMathProblem function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const MathSolverInputSchema = z.object({
  problem: z.string().describe('The mathematical problem or equation to solve.'),
});
type MathSolverInput = z.infer<typeof MathSolverInputSchema>;

const MathSolverOutputSchema = z.object({
  solution: z.string().describe('The solution to the mathematical problem, with steps if possible.'),
});
type MathSolverOutput = z.infer<typeof MathSolverOutputSchema>;

export async function solveMathProblem(input: MathSolverInput): Promise<MathSolverOutput> {
  return mathSolverFlow(input);
}

const prompt = ai.definePrompt({
  name: 'mathSolverPrompt',
  input: {schema: MathSolverInputSchema},
  output: {schema: MathSolverOutputSchema},
  prompt: `You are a powerful AI math solver. Your specialty is symbolic manipulation of equations.
Solve the following mathematical problem. Provide a step-by-step solution if applicable.

Problem: {{{problem}}}
`,
});

const mathSolverFlow = ai.defineFlow(
  {
    name: 'mathSolverFlow',
    inputSchema: MathSolverInputSchema,
    outputSchema: MathSolverOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
