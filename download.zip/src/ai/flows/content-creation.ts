// Content Creation flow
'use server';
/**
 * @fileOverview Generates marketing and website copy based on a brief user description.
 *
 * - generateContent - A function that generates content.
 * - ContentInput - The input type for the generateContent function.
 * - ContentOutput - The return type for the generateContent function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ContentInputSchema = z.object({
  businessDescription: z
    .string()
    .describe('A brief description of the business or product.'),
});
type ContentInput = z.infer<typeof ContentInputSchema>;

const ContentOutputSchema = z.object({
  copy: z.string().describe('The generated marketing and website copy.'),
});
type ContentOutput = z.infer<typeof ContentOutputSchema>;

export async function generateContent(input: ContentInput): Promise<ContentOutput> {
  return contentCreationFlow(input);
}

const contentCreationPrompt = ai.definePrompt({
  name: 'contentCreationPrompt',
  input: {schema: ContentInputSchema},
  output: {schema: ContentOutputSchema},
  prompt: `You are a marketing expert. Create compelling marketing and website copy based on the following description.

Description: {{{businessDescription}}}

Output the marketing copy in JSON format.`,
  config: {
    safetySettings: [
      {
        category: 'HARM_CATEGORY_HATE_SPEECH',
        threshold: 'BLOCK_ONLY_HIGH',
      },
      {
        category: 'HARM_CATEGORY_DANGEROUS_CONTENT',
        threshold: 'BLOCK_NONE',
      },
      {
        category: 'HARM_CATEGORY_HARASSMENT',
        threshold: 'BLOCK_MEDIUM_AND_ABOVE',
      },
      {
        category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT',
        threshold: 'BLOCK_LOW_AND_ABOVE',
      },
    ],
  },
});

const contentCreationFlow = ai.defineFlow(
  {
    name: 'contentCreationFlow',
    inputSchema: ContentInputSchema,
    outputSchema: ContentOutputSchema,
  },
  async input => {
    const {output} = await contentCreationPrompt(input);
    return output!;
  }
);
