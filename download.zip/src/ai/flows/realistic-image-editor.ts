// Realistic Image Editor
'use server';

/**
 * @fileOverview An AI agent for realistically editing images based on user descriptions.
 *
 * - realisticImageEditor - A function that handles the image editing process.
 * - RealisticImageEditorInput - The input type for the realisticImageEditor function.
 * - RealisticImageEditorOutput - The return type for the realisticImageEditor function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const RealisticImageEditorInputSchema = z.object({
  photoDataUri: z
    .string()
    .describe(
      "A photo to edit, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
  editDescription: z.string().describe('The description of the edits to perform on the image.'),
});
type RealisticImageEditorInput = z.infer<typeof RealisticImageEditorInputSchema>;

const RealisticImageEditorOutputSchema = z.object({
  editedPhotoDataUri: z.string().describe('The edited photo, as a data URI.'),
});
type RealisticImageEditorOutput = z.infer<typeof RealisticImageEditorOutputSchema>;

export async function realisticImageEditor(input: RealisticImageEditorInput): Promise<RealisticImageEditorOutput> {
  return realisticImageEditorFlow(input);
}

const prompt = ai.definePrompt({
  name: 'realisticImageEditorPrompt',
  input: {schema: RealisticImageEditorInputSchema},
  output: {schema: RealisticImageEditorOutputSchema},
  prompt: `You are an expert photo editor. A user has provided an image and a description of the edits they want to perform.

  Original Photo: {{media url=photoDataUri}}
  Edits: {{{editDescription}}}

  Create an edited version of the photo with the specified edits.
  Ensure that the result looks realistic and natural.
  Return the edited photo as a data URI.
`,
});

const realisticImageEditorFlow = ai.defineFlow(
  {
    name: 'realisticImageEditorFlow',
    inputSchema: RealisticImageEditorInputSchema,
    outputSchema: RealisticImageEditorOutputSchema,
  },
  async input => {
    const {media} = await ai.generate({
      model: 'googleai/gemini-2.0-flash-preview-image-generation',
      prompt: [
        {media: {url: input.photoDataUri}},
        {text: input.editDescription},
      ],
      config: {
        responseModalities: ['TEXT', 'IMAGE'],
      },
    });
    return {editedPhotoDataUri: media!.url!};
  }
);
