'use server';
/**
 * @fileOverview An AI agent for writing professional resumes and CVs.
 *
 * - writeResume - A function that generates a resume.
 * - WriteResumeInput - The input type for the writeResume function.
 * - WriteResumeOutput - The return type for the writeResume function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const WorkExperienceSchema = z.object({
  company: z.string().describe('The name of the company.'),
  role: z.string().describe('The job title or role.'),
  startDate: z.string().describe('The start date of the employment.'),
  endDate: z.string().describe('The end date of the employment (or "Present").'),
  description: z.string().describe('A description of responsibilities and achievements in the role.'),
});

const EducationSchema = z.object({
  institution: z.string().describe('The name of the educational institution.'),
  degree: z.string().describe('The degree or qualification obtained.'),
  startDate: z.string().describe('The start date of the education.'),
  endDate: z.string().describe('The end date of the education.'),
});

const WriteResumeInputSchema = z.object({
  fullName: z.string().describe('The full name of the applicant.'),
  email: z.string().email().describe('The email address of the applicant.'),
  phoneNumber: z.string().describe('The phone number of the applicant.'),
  address: z.string().describe('The physical address of the applicant.'),
  professionalSummary: z.string().describe('A brief professional summary or objective.'),
  workExperience: z.array(WorkExperienceSchema).describe('A list of work experiences.'),
  education: z.array(EducationSchema).describe('A list of educational qualifications.'),
  skills: z.string().describe('A comma-separated list of relevant skills.'),
});
type WriteResumeInput = z.infer<typeof WriteResumeInputSchema>;

const WriteResumeOutputSchema = z.object({
  resume: z.string().describe('The generated resume content in Markdown format.'),
});
type WriteResumeOutput = z.infer<typeof WriteResumeOutputSchema>;

export async function writeResume(input: WriteResumeInput): Promise<WriteResumeOutput> {
  return writeResumeFlow(input);
}

const prompt = ai.definePrompt({
  name: 'writeResumePrompt',
  input: { schema: WriteResumeInputSchema },
  output: { schema: WriteResumeOutputSchema },
  prompt: `You are an expert resume writer and career coach. Your task is to create a professional and compelling resume in Markdown format based on the information provided.

The resume should be well-structured, easy to read, and highlight the applicant's strengths. Use professional language and action verbs.

Format the output strictly in Markdown. Start with the applicant's name and contact information, followed by the professional summary, work experience, education, and skills sections.

**Applicant Details:**
- **Full Name:** {{{fullName}}}
- **Contact:** {{{email}}} | {{{phoneNumber}}} | {{{address}}}

**Professional Summary:**
{{{professionalSummary}}}

**Work Experience:**
{{#each workExperience}}
- **{{role}}** at {{company}} ({{startDate}} - {{endDate}})
  - {{description}}
{{/each}}

**Education:**
{{#each education}}
- **{{degree}}**, {{institution}} ({{startDate}} - {{endDate}})
{{/each}}

**Skills:**
{{{skills}}}

Generate the complete resume now.
`,
});

const writeResumeFlow = ai.defineFlow(
  {
    name: 'writeResumeFlow',
    inputSchema: WriteResumeInputSchema,
    outputSchema: WriteResumeOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);
    return output!;
  }
);
