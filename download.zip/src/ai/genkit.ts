import {genkit} from 'genkit';
import {googleAI} from '@genkit-ai/googleai';
import { defineSecret } from 'genkit/secrets';

// This tells Genkit that the API key is stored in a secret manager.
// For local development, it will look for a .env.local file.
// For deployment, this is managed in your hosting provider's dashboard.
defineSecret({
  id: 'GOOGLE_API_KEY',
  description: 'The Google AI API key',
});

export const ai = genkit({
  plugins: [
    googleAI({
      apiKey: process.env.GOOGLE_API_KEY,
    }),
  ],
  model: 'googleai/gemini-2.0-flash',
});
